import React from "react";


// Class component
class NotFoundErrorPage extends React.Component {

    render() {
        return <h1>Error Page!</h1>
    }

}

export default NotFoundErrorPage;
