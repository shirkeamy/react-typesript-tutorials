import React from "react";

function CompanyMaster() {

    return (
        // <></> this is jsx element
        <>
            <h2>This is company master page</h2>
            <p>
                Lorem ipsum, dolor sit amet consectetur adipisicing elit. Aspernatur autem iure odit facilis sed laudantium dignissimos adipisci, cumque rerum, dicta veritatis voluptates nesciunt atque perferendis tenetur fuga pariatur. Debitis, doloribus.
            </p>
            <h3>About</h3>
            <p>
                Lorem ipsum dolor sit amet consectetur adipisicing elit. Eligendi necessitatibus suscipit illum officia doloremque voluptas assumenda dicta excepturi alias voluptate.
            </p>
        </>
    )
}

export default CompanyMaster;